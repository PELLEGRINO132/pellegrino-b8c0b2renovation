# Pellegrino Rénovation — site vitrine

Site statique de **Pellegrino Rénovation** (Eric Pellegrino), artisan plâtrier-staffeur et sculpteur bas-relief à Condom (Gers) : plâtrerie, isolation, carrelage, peinture.

Production : https://pellegrino-b8c0b2renovation.netlify.app/ (déploiement continu Netlify depuis la branche `main`).

## Structure

| Fichier / dossier | Rôle |
|---|---|
| `index.html` | Accueil |
| `services.html` | Prestations |
| `realisations.html` | Galeries de chantiers |
| `contact.html` | Contact et formulaire (Formspree) |
| `images/` | Photos du site (nom : `chantier-NN-description.jpg`) |
| `archives/` | Photos non publiées (exclues par `robots.txt`) |
| `sitemap.xml`, `robots.txt` | Référencement |

## Mettre à jour le site

1. Ajouter ou remplacer les fichiers via l'interface web GitHub (« Add file → Upload files »).
2. Netlify redéploie automatiquement en une minute environ.
3. Après l'ajout d'une photo dans `images/`, vérifier que le nom référencé dans le HTML correspond exactement au fichier.

## Contact

Pellegrino Rénovation — 9 rue Grichet, 32100 Condom — 06 48 06 18 92
